# Extended Techniques Mod
A mod for Cataclysm Dark Days Ahead, it adds more techniques to let weapon classes have apparent play styles other than "does it have a reach attack?" or "does it have rapid strikes?" and it also makes melee more interesting.

I tried to keep the damage balanced and also added scaling damage and movecosts to make it so certain attacks or weapons carry different risks.

Anyways, have fun and report any bugs you find.
